//
//  expEng.h
//  expEng-iOS
//
//  Created by Andy Cleal on 31/01/2023.
//

#ifndef expEng_h
#define expEng_h

@interface expEng : NSObject



- (void)userSet:(NSString*)sLearntSet;
- (NSString*)userGet;
- (void)dataNewFrame:(float[])fVals;
- (NSString*)dataStartSaving;
- (void)dataStopSaving;
- (bool)dataIsSaving;


@end


#endif /* expEng_h */
