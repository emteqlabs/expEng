//
//  expEng_iOS.h
//  expEng-iOS
//
//  Created by Andy Cleal on 31/01/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for expEng_iOS.
FOUNDATION_EXPORT double expEng_iOSVersionNumber;

//! Project version string for expEng_iOS.
FOUNDATION_EXPORT const unsigned char expEng_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <expEng_iOS/PublicHeader.h>
//#import <expEng-iOS/expEng.h>
#include "expEng.h"

